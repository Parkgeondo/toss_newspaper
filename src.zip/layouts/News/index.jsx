import { NewsWrapper, StyledScrollbar, ChangeScreen } from './styles';
import NewsBox from '../../Component/NewsBox';
import SavedNews from '../../Component/SavedNews'
import Tab from '../Tab';

import { newsData } from '../../data/newsData';
import { useRef, useState, useEffect } from 'react';
import { useMotionValue, animate } from "framer-motion";

import ScrollTracker from'../../utile/useScrollTraker';
import Syn from '../../utile/syn';
import { useDetective } from '../../utile/useDetective';

const News = ({tabs, selectedTab, setSelectedTab, savedNews, setSavedNews,temSavedNews,setTemSavedNews, setProgress, scroll, setScroll, setTabControl}) => {
  const x = useMotionValue(0);

  const newsScrollbarRef = useRef(null);
  const savedScrollbarRef = useRef(null);
  const [rootEl, setRootEl] = useState(null); // ✅ DOM 연결된 후 root 설정

  const pageMove = (moveLocation) => {
    animate(x, moveLocation, { type: "spring", stiffness: 300, damping: 30 });
  }

  useEffect(() => {
    if (selectedTab === 'saved') {
      pageMove(-375);
    } else if (selectedTab === 'news') {
      pageMove(0);
    }
  }, [selectedTab]);

  const handleDragEnd = (e, info) => {
    if (info.offset.x < -150 && selectedTab === tabs[0]) {
      pageMove(-375);
      setSelectedTab(tabs[1])
    } else if(info.offset.x >= -150 && selectedTab === tabs[0]){
      pageMove(0);
      setSelectedTab(tabs[0])
    } else if(info.offset.x > 150 && selectedTab === tabs[1]){
      pageMove(0);
      setSelectedTab(tabs[0])
    } else if(info.offset.x <= 150 && selectedTab === tabs[1]){
      pageMove(-375);
      setSelectedTab(tabs[1])
    }
  }

  const [dragging, setDragging] = useState(false);

  // ✅ 실제 DOM이 연결된 이후에 observer 작동
  const [refs, visibilities] = useDetective({ root: rootEl, threshold: 0.3 });

  return (
    <ChangeScreen
      style={{ x }}
      drag="x"
      onDragEnd={(e, info) => {
        setDragging(false);
        handleDragEnd(e, info);
      }}
      onDragStart={() => {
        setDragging(true);
      }}
      dragConstraints={{ left: -375, right: 0 }}
    >
      <NewsWrapper scroll={scroll[0]} ref={newsScrollbarRef}>
        <ScrollTracker scrollRef={newsScrollbarRef} tabs={tabs} newsScrollbarRef={newsScrollbarRef} savedScrollbarRef={savedScrollbarRef} scroll={scroll} setScroll={setScroll} otherRef={savedScrollbarRef} id={0} setTabControl={setTabControl} dragging={dragging} selectedTab={selectedTab}/>
        {newsData.map((data,index) => (
          <NewsBox key={data.id} {...data} index={index} savedNews={savedNews} setSavedNews={setSavedNews} temSavedNews={temSavedNews} setTemSavedNews={setTemSavedNews} setProgress={setProgress}/>
        ))}
      </NewsWrapper>

      <NewsWrapper
        scroll={scroll[1]}
        ref={(el) => {
          savedScrollbarRef.current = el;
          setRootEl(el); // ✅ ref 설정 후 root 동기화
        }}
      >
        <ScrollTracker visibilities={visibilities} scrollRef={savedScrollbarRef} tabs={tabs} newsScrollbarRef={newsScrollbarRef} savedScrollbarRef={savedScrollbarRef} scroll={scroll} setScroll={setScroll} otherRef={newsScrollbarRef} id={1} setTabControl={setTabControl} dragging={dragging} selectedTab={selectedTab}/>
        {savedNews.map((data, index) => (
          <SavedNews ref={(el)=>{(refs.current[index] = el)}} key={data} id={data} savedScrollbarRef={savedScrollbarRef} />
        ))}
      </NewsWrapper>
    </ChangeScreen>
  );
};

export default News;
