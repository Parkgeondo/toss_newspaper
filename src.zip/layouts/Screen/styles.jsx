import styled from '@emotion/styled';

export const Test = styled.div`
position:absolute;
top: 100px;
background:red;
`