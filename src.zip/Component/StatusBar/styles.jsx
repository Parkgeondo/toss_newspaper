import styled from '@emotion/styled';

export const StatusBarstyle = styled.div`
position:absolute;
top:0;
z-index:999;
`