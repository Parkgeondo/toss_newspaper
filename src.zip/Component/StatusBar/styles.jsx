import styled from '@emotion/styled';

export const StatusBarstyle = styled.div`
background-color:white;
display:flex;
height: 48px;
width:100%;
justify-content: space-between;
display:flex;
align-items: center;
padding-left: 28px;
position:absolute;
top:0;
z-index:999;
`