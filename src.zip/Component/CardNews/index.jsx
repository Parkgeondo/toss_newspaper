import { useMotionValue, useMotionValueEvent, useTransform } from "framer-motion";
import { CardNews_wrap } from "./styles"
import card_effect from "../../img/card_effect.png"
import { useEffect } from "react";


function CardNews({data, cardIndex, card_gap_width , card_width, app_width, isFocused,x , card_distance}) {
      // 각 카드의 중심 기준 위치 (0, 1, 2, ...)

  // 왜 이렇게 되는지 확인
const distance = useTransform(x, (latestX) => {
  const screenCenter = app_width * 0.5;
  const cardCenterX = card_distance + latestX;
  const raw = Math.abs(cardCenterX - screenCenter + card_gap_width*0.5);
  const max = card_width * 2;
  const clamped = Math.min(raw, max);
  const normalized = clamped / max;
  return 1 - normalized * 0.2; // scale: 1.0 → 0.8
});

    const y = useMotionValue(0);

    const width = useTransform(y, [0, -300], ["265px", "400px"]);
    const height = useTransform(y, [0, -300], ["400px", "600px"]);
  
    useMotionValueEvent(y, "change", (latest) => {
      console.log(latest)
    })


  if (data.isBlank) {
    return <CardNews_wrap
    style={{ opacity:'0' }}
    />;
  }

  return(
    <CardNews_wrap
      drag="y"
      dragConstraints={{ top: -1000, bottom: 0 }}
      dragDirectionLock   // ✅ 중요!
      style={{
        y, // ✅ 이거 필수!
        scale: distance,
        width,
        height,
        transformOrigin: "center top"
      }}
    >
      <img src={card_effect} className="card_effect" alt="" />
      <div className="gradient"></div>
      <img src={data.bigImage} className="thumnail" alt="" />
      <div className="text">
        <div className="publisher">
          <img src={data.publisherImg} alt="" />
          {data.publisher}
        </div>
        <div className="title">{data.title}</div>
        <div className="badge">{data.category}</div>
        <div className="badge">{data.date}</div>
      </div>
    </CardNews_wrap>
  )
}

export default CardNews