import { motion } from "framer-motion";

export default function CardDetail({ card, onClose }) {
  return (
    <motion.div
      layoutId={`card-${card.id}`}
      className="fixed inset-0 p-8 bg-white z-50 rounded-xl shadow-xl"
      onClick={onClose}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <h2 className="text-2xl font-bold mb-4">{card.title}</h2>
      <p>{card.content}</p>
    </motion.div>
  );
}