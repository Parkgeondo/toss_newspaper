import CircleNewsRow from "../../Component/CircleNews";

const TabTitle = ({tabNavi, savedNews,temSavedNews,progress}) => {
  return(
    <div style={{display:'flex', gap:'4px', alignItems:'center'}}>
      저장한 뉴스
      <CircleNewsRow savedNews={savedNews} temSavedNews={temSavedNews} progress={progress}/>
    </div>
  )
}

export default TabTitle;