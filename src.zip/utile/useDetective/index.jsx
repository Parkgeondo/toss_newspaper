import { useEffect, useRef, useState } from 'react';

export function useDetective({ root, threshold }) {
  const refs = useRef([]);
  const [visibleEntries, setVisibleEntries] = useState([]);

  useEffect(() => {
    if (!root) return;

    const observer = new IntersectionObserver((entries) => {
      const visibilities = entries.map((entry) => ({
        target: entry.target,
        isVisible: entry.isIntersecting,
      }));
      setVisibleEntries(visibilities);
    }, { root, threshold });

    refs.current.forEach((el) => {
      if (el) observer.observe(el);
    });

    return () => {
      refs.current.forEach((el) => {
        if (el) observer.unobserve(el);
      });
    };
  }, [root, threshold]); // ✅ 옵저버 재생성 조건을 명확하게

  return [refs, visibleEntries];
}
