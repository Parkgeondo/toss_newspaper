const getIndex = (_, index) => index;

export default getIndex;