import React, { useRef, useState } from "react";
import { motion, useMotionValue, useTransform } from "framer-motion";
import { interpolate } from "flubber";
import { SaveBox_front, SaveBox_back, CircleNews_wrap } from "./styles";
import CircleNewsRow from "../CircleNews";
import anime from "animejs";

// 1. path 배열은 컴포넌트 밖에서 선언!
const saveBox_front_1 = "M171 0.000106365C181.941 0.000109071 191 9.05898 191 20.0001C191 30.9412 181.941 40.0001 171 40.0001H20C9.05888 40.0001 0 30.9412 0 20.0001C0 9.05898 9.05888 0.000106743 20 0.000106365H88.5C89 0.000106365 89 6.27045e-05 90 6.27045e-05C91 6.27045e-05 90.1716 0 91 0H98C98.8284 0 98 0 99 9.29538e-05C100 0 100 0.000106365 100.5 0.000106365H171Z";
const saveBox_front_2 = "M271 0C280.941 2.70588e-06 289 8.05888 289 18V51C289 60.9411 280.941 69 271 69H18C8.05888 69 0 60.9411 0 51V18C0 8.05888 8.05888 3.78501e-07 18 0H88.5C87.6716 0 87 0.671573 87 1.5C87 2.32843 87.6716 3 88.5 3H200.5C201.328 3 202 2.32843 202 1.5C202 0.671573 201.328 0 200.5 0H271Z";
const saveBox_front_3 = "M0.441162 11.5769C0.441162 5.45931 5.38022 0.5 11.4729 0.5H96.3167C97.8083 0.5 99.4412 0.500032 100.441 0.500028L117.941 0.5C118.941 0.5 120.45 0.5 121.941 0.5H198.026C199.518 0.5 200.941 0.5 201.941 0.500038H219.441C220.441 0.500061 222.074 0.5 223.566 0.5H308.409C314.502 0.5 319.441 5.45931 319.441 11.5769V65.4231C319.441 71.5407 314.502 76.5 308.409 76.5H11.4729C5.38022 76.5 0.441162 71.5407 0.441162 65.4231V11.5769Z";
const saveBox_front_4 = "M0 12C0 5.37258 5.37258 0 12 0H104.291C105.913 0 107.519 0.329034 109.011 0.96721L127.864 9.03279C129.356 9.67097 130.962 10 132.584 10H214.416C216.038 10 217.644 9.67097 219.136 9.03279L237.989 0.967211C239.481 0.329035 241.087 0 242.709 0H335C341.627 0 347 5.37258 347 12V66C347 72.6274 341.627 78 335 78H12C5.37259 78 0 72.6274 0 66V12Z";
const saveBox_back_2 = "M0 18C0 8.05888 8.05888 0 18 0H271C280.941 0 289 8.05888 289 18V51C289 60.9411 280.941 69 271 69H18C8.05888 69 0 60.9411 0 51V18Z";
const saveBox_back_3 = "M0 12C0 5.37258 5.37258 0 12 0H307C313.627 0 319 5.37258 319 12V75C319 81.6274 313.627 87 307 87H12C5.37259 87 0 81.6274 0 75V12Z";
const saveBox_back_4 = "M0 12C0 5.37258 5.37258 0 12 0H335C341.627 0 347 5.37258 347 12V103C347 109.627 341.627 115 335 115H12C5.37259 115 0 109.627 0 103V12Z";

// 순서 원하는대로 변경 가능
const paths = [
  saveBox_front_1,
  saveBox_front_2,
  saveBox_front_3,
  saveBox_front_4,
  saveBox_back_2,
  saveBox_back_3,
  saveBox_back_4
];

function SaveBox({ savedNews, temSavedNews }) {
  return (
    <>
      <SaveBox_front>
        <CircleNews_wrap>
          <p style={{
            maxWidth: "180px",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis"
          }}>
            {savedNews.length ? '저장된 뉴스' : '뉴스를 여기로 끌어 저장'}
          </p>
          <CircleNewsRow savedNews={savedNews} temSavedNews={temSavedNews} />
        </CircleNews_wrap>
      </SaveBox_front>
      <SaveBox_back>
        <svg width="289" height="69" viewBox="0 0 289 69">
        </svg>
      </SaveBox_back>
    </>
  );
}

export default SaveBox;
