import styled from '@emotion/styled';
import { motion } from "framer-motion";


//물결원 범위
export const Refresh_wrap = styled(motion.div)`
z-index: 120;
position: absolute;
left: 2%;
`